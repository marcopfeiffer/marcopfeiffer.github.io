from django import forms

class AddPostForm(forms.Form):
    txtPost = forms.Field(widget=forms.Textarea({'rows': '3', 'maxlength': 100, 'class': 'form-control', 'placeholder': "Add post text here"}), 
                            label="Add a new post", required=True)
