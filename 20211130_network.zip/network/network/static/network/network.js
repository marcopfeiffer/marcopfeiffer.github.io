document.addEventListener('DOMContentLoaded', function() {

  	// Use buttons to toggle between views
  
	document.querySelector('#allPosts').addEventListener('click', function() { load_post_form() });
	document.querySelector('#following').addEventListener('click', function() { load_following() });

});

function load_post_form() {

	event.preventDefault();
	
	document.querySelector('#following-view').style.display = 'none';
	document.querySelector('#postAdd-view').style.display = 'block';		
	
	var div = document.createElement("div");
	div.className = "d-flex w-100 justify-content-between";
	
	var ta = document.createElement("textarea");
	ta.placeholder = "dynamisch angelegt";
	
	div.appendChild(ta);
	
	document.querySelector("#postAdd-view").appendChild(div);
  
	console.log("load post form");
}

function load_following() {



	event.preventDefault();
	
	document.querySelector('#following-view').style.display = 'block';
	document.querySelector('#postAdd-view').style.display = 'none';	
  
	console.log("load following");
}